package project.wagadougou.test_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
